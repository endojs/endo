export { decodeBase64 } from './src/decode.js';
