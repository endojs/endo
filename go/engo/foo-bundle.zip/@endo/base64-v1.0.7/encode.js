export { encodeBase64 } from './src/encode.js';
