export { encodeBase64 } from './src/encode.js';
export { decodeBase64 } from './src/decode.js';
export { btoa } from './btoa.js';
export { atob } from './atob.js';
